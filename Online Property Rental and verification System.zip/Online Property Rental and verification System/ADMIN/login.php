<?php
 include_once("../db/config.php");

$username = $_REQUEST['username'];
$pass = $_REQUEST[ 'pwd'];

 $sql = "select * from tbl_admin where USERNAME='$username' and PASSWORD='$pass' ";

$res = $conn->query($sql);
$rec = $res->fetch_array();
if (mysqli_num_rows($res) == 1) {
    session_start();
    $_SESSION['Adminloginstatus'] = true;
 
    header('location:dashboard.php?login=succesfully');
} else {
    header('location:index.php?error=error');
}

 ?>