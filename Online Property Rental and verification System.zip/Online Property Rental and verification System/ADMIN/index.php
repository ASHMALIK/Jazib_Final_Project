<?php
session_start();
if (isset($_SESSION['Adminloginstatus']) and $_SESSION['Adminloginstatus'] == true) {
    header('location:dashboard.php');
} else {


    ?>

<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="../css/main.css">


</head>

<body class="body">
    <?php
    if (isset($_GET['success'])) {

        ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong>Login successfully</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php 
} else if (isset($_GET['error'])) {
    ?>
    <div class="alert alert-warning alert-dismissible " role="alert">
        <strong>Something Wrong Check it!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php 
}
?>
    <div class="containeradmin">
        <div class="container text-center">
            <div class="col-sm-6">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h2>Admin panel</h2>
                    </div>
                    <br>
                    <div class="panel-body">
                        <form class="form-horizontal" method="post" action="login.php">

                            <div class="form-group">
                                <label class="control-label col-sm-2">UserName:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" required="">
                                </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="pwd">Password:</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd" required="">
                                </div>
                            </div>
                            <br>
                            <div class="form-group">

                                <input type="submit" value="Login" name="submit" class="btn  btn-danger">

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php 
}
?> 