<?php
include_once("../../db/config.php");


   $id=$_GET['id'];
    
   $sql = "update tbl_agents set STATUS='1' where AGENT_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../agent.php?success=success');

    
 ?>