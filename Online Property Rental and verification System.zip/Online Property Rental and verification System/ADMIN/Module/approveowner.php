<?php
include_once("../../db/config.php");


   $id=$_GET['id'];
    
   $sql = "update tbl_owners set STATUS='1' where OWNER_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../dashboard.php?success=success');

    
 ?>