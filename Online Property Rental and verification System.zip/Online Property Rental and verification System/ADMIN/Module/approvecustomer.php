<?php
include_once("../../db/config.php");


   $id=$_GET['id'];
    
   $sql = "update tbl_customers set STATUS='1' where CUSTOMER_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../customer.php?success=success');

    
 ?>