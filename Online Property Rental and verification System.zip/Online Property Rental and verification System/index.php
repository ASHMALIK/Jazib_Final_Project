<?php
include_once('db/config.php');
?>
<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">


</head>

<body>

    <div class="jumbotron">
        <div class="container text-center">
            <h2>Online Property Rental and verification System</h2>

        </div>
    </div>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="property.php"><span class="glyphicon glyphicon-home"></span>Property</a></li>
                    <li><a href="agent.php"><span class="glyphicon glyphicon-user"></span>Agents</a></li>
                    <li><a href="owner.php"><span class="glyphicon glyphicon-user"></span>Owners</a></li>
                </ul>

            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">

            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <img src="IMAGES/RS09-10-1-624x371.jpg" width="1229" height="203" alt="Image">
                        <div class="carousel-caption">
                            <h3>Properties Available</h3>
                            <p>For Rent..</p>
                        </div>
                    </div>

                    <div class="item">
                        <img src="IMAGES/img.jpg" width="1229" height="203" alt="Image">
                        <div class="carousel-caption">
                            <h3>Properties Available</h3>
                            <p>For Rent..</p>
                        </div>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>


        </div>
    </div>
    <br>
    <?php 
    $sql = "select * from tbl_property";
    $res = $conn->query($sql);
    while ($rec = $res->fetch_array()) {
        extract($rec);
        ?>

    <div class="container text-center">
        <div class="row">
            <div class="col-sm-4">
                <div class="panel panel-primary">
                    <?php
                    if ($PROPERTY_STATUS == 0) {
                        ?>
                    <div class="panel-heading">AVAILABLE FOR RENT</div>
                    <?php

                } elseif ($PROPERTY_STATUS == 1) {
                    ?>
                    <div class="panel-heading">NOT AVAILABLE FOR RENT</div>
                    <?php

                }
                ?>
                    <div class="panel-body"><img src="Property_images/<?= $IMAGE ?>" class="img-responsive" style="width:328px" alt="Image"></div>
                    <div class="panel-footer"><a href="customer.php">Buy a Luxory Property for Rent <span class="glyphicon glyphicon-arrow-right"></a></div>
                </div>
            </div>
            <?php 
        }
        ?>

        </div>
    </div>
    <br><br>

    <footer class="container-fluid text-center">
        <p>Online Property Rental and verification System @Copyright</p>

    </footer>



</body>

</html> 