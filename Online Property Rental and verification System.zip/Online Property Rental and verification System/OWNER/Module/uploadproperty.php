<?php
session_start();
include_once("../../db/config.php");
$id = $_SESSION['ID'];
if (isset($_POST['submit'])) {

 
    $image=$_FILES[ 'image']['name'];
    $image_tmp=$_FILES[ 'image']['tmp_name'];
    move_uploaded_file($image_tmp,"../../Property_images/$image");

  $agent_id = $_POST[ 'agent_id'];
  $owner_id = $_SESSION['ID'];
  $typeofproperty = $_POST[ 'typeofproperty'];
  $city = $_POST[ 'city'];
  $street_no = $_POST[ 'street_no'];
  $house_no = $_POST[ 'house_no'];
  $house_name = $_POST[ 'house_name'];
  $size = $_POST[ 'size'];
  $totalrooms = $_POST['totalrooms'];
  $rent = $_POST[ 'rent'];
 $rentagreement = $_POST['rentagreement'];

 $sql = "insert into tbl_property (OWNER_ID,AGENT_ID,PROPERTY_TYPE,CITY,STREET_NO,HOUSE_NO,HOUSE_NAME,SIZE,TOTAL_ROOMS,IMAGE,RENT,RENT_AGREEMENT)values(' $owner_id ',' $agent_id','$typeofproperty',' $city','$street_no','$house_no','$house_name','$size','$totalrooms','$image','$rent',' $rentagreement')";

  $res = $conn->query($sql);
  header('location:../property.php?success=success');
} else {
  header('location:../property.php?error=error');
}
 