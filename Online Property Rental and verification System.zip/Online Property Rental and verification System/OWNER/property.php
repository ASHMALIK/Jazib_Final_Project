<?php
include_once('../db/config.php');
session_start();
if (isset($_SESSION['ownerloginstatus']) and $_SESSION['ownerloginstatus'] == true) {

    ?>

<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" media="screen" href="../css/main.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>


    <div class="navbar navbar-inverse">
        <div class="container-fluid">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="dashboard.php"><span class="glyphicon glyphicon-home">Home</a>
        <a href="property.php"><span class="glyphicon glyphicon-home">Properties</a>
        <a href="agent.php"><span class="glyphicon glyphicon-user">Agents</a>
        <a href="customer.php"><span class="glyphicon glyphicon-user">Customers</a>
        <a href="saled_property.php"><span class="glyphicon glyphicon-home">Saled_property</a>
    </div>



    <div id="main">
        <?php
        if (isset($_GET['success'])) {

            ?>
        <div class="alert alert-success alert-dismissible " role="alert">
            <strong>Property Uploaded successfully!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    } else if (isset($_GET['error'])) {
        ?>
        <div class="alert alert-warning alert-dismissible " role="alert">
            <strong>Something Wrong Check it!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    }
    ?>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
        <div class="container">
            <h1 class="text-center"><span class="glyphicon glyphicon-home"></span>Upload new Property</h1>



            <form enctype="multipart/form-data" method="post" action="Module/uploadproperty.php">
                <div class="form-group">
                    <label>SELECT_AGENT:</label>
                    <select class="form-control" id="text" placeholder="select the agent" name="agent_id" required="">
                        <?php 
                        $sql2 = "select * from tbl_agents ";
                        $res2 = $conn->query($sql2);
                        while ($rec2 = $res2->fetch_array()) {
                            extract($rec2);
                            ?>

                        <option value="<?= $AGENT_ID ?>">
                            <?= $AGENT_NAME ?>
                        </option>
                        <?php 
                    }
                    ?>

                    </select>
                </div>
                <div class="form-group">
                    <label>PROPERTY_TYPE :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter Type of property" name="typeofproperty" required="">
                </div>
                <div class="form-group">
                    <label>CITY :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter city name" name="city" required="">
                </div>
                <div class="form-group">
                    <label>STREET_NO :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter street no." name="street_no" required="">
                </div>
                <div class="form-group">
                    <label>HOUSE_NO :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter house no." name="house_no" required="">
                </div>
                <div class="form-group">
                    <label>HOUSE_NAME :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter Your house name" name="house_name" required="">
                </div>
                <div class="form-group">
                    <label>SIZE :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter Your house size" name="size" required="">
                </div>
                <div class="form-group">
                    <label>TOTAL_ROOMS :</label>
                    <input type="number" class="form-control" id="text" placeholder="Enter no. of rooms" name="totalrooms" required="">
                </div>
                <div class="form-group">
                    <label>IMAGE :</label>
                    <input type="file" class="form-control" id="text" placeholder="upload image" name="image" required="">
                </div>
                <div class="form-group">
                    <label>RENT :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter house rent" name="rent" required="">
                </div>
                <div class="form-group">
                    <label>RENT_AGREEMENT :</label>
                    <textarea class="form-control" id="text" placeholder="Enter the agreement here..." name="rentagreement" required=""></textarea>
                </div>

                <input type="submit" name="submit" Value="upload" class="btn btn-info">
                <form>
        </div>
        <br>

        <div class="container-fluid">

            <div class="row">


                <div class="col-sm-12">
                    <div class="white-box">
                        <h3 class="box-title m-b-0">Data Export</h3>
                        <p class="text-muted m-b-30">Export data to CSV, Excel, PDF & Print</p>
                        <div class="table-responsive">
                            <table id="example23" class="display nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>PROPERTY_ID</th>
                                        <th>OWNER NAME</th>
                                        <th>OWNER EMAIL</th>
                                        <th>OWNER ADDRESS</th>
                                        <th>OWNER CONTACT NO.</th>
                                        <th>CITY</th>
                                        <th>HOUSE_NAME</th>
                                        <th>PROPERTY_STATUS</th>
                                        <th>ACTION</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $id = $_SESSION['ID'];
                                    $sql1 = "select * from tbl_owners where OWNER_ID='$id' ";
                                    $res1 = $conn->query($sql1);
                                    while ($rec1 = $res1->fetch_array()) {
                                        extract($rec1);
                                        ?>

                                    <?php 
                                    $id = $_SESSION['ID'];
                                    $sql = "select * from tbl_property where OWNER_ID='$id' ";
                                    $res = $conn->query($sql);
                                    while ($rec = $res->fetch_array()) {
                                        extract($rec);
                                        ?>





                                    <tr>
                                        <td class="text-center"><?= $PROPERTY_ID ?></td>
                                        <td class=" text-center"><?= $OWNER_NAME ?></td>
                                        <td class="text-center"><?= $OWNER_EMAIL ?></td>
                                        <td class="text-center"><?= $OWNER_ADDRESS ?></td>
                                        <td class="text-center"><?= $OWNER_CONTACT ?></td>
                                        <td class="text-center"><?= $CITY ?></td>
                                        <td class="text-center"><?= $HOUSE_NAME ?></td>
                                        <?php
                                        if ($PROPERTY_STATUS == 0) {
                                            ?>
                                        <td class="text-center">AVAILABLE FOR RENT</td>
                                        <?php

                                    } elseif ($PROPERTY_STATUS == 1) {
                                        ?>
                                        <td class="text-center">NOT AVAILABLE FOR RENT</td>
                                        <?php

                                    }
                                    ?>

                                        <td class="text-center"><a href="Viewproperty.php?id=<?= $PROPERTY_ID ?>&agent_id=<?= $AGENT_ID ?>"><span class="glyphicon glyphicon-eye-open"></a></td>

                                    </tr>
                                    <?php

                                }
                            }
                            ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>

        </div>
    </div>





    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
    </script>

    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>

    <script>
        $('#example23').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'csv', 'excel', 'pdf', 'print'
            ]
        });
    </script>



</body>

</html>

<?php

} else {
    header('location:logout.php');
}
?> 