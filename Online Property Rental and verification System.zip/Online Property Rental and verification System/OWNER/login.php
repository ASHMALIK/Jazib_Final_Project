<?php
 include_once("../db/config.php");

$email = $_REQUEST[ 'email'];
$pass = $_REQUEST[ 'pwd'];

 $sql = "select * from tbl_owners where OWNER_EMAIL='$email' and OWNER_PASSWORD='$pass' and STATUS='1' ";

$res = $conn->query($sql);
$rec = $res->fetch_array();
if (mysqli_num_rows($res) == 1) {
    session_start();
    $_SESSION[ 'ownerloginstatus'] = true;
   $_SESSION['ID'] = $rec[ 'OWNER_ID'];

    header('location:dashboard.php?login=succesfully&ID=' . $_SESSION['ID']);
} else {
    header('location:../owner.php?error=error');
}

 ?>