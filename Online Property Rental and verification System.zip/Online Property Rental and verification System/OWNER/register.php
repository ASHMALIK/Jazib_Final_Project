<?php
include_once("../db/config.php");

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pwd'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $contactno=$_POST['contactno'];
    $address=$_POST['address'];
   
    $sql = "insert into tbl_owners (OWNER_NAME,OWNER_EMAIL,OWNER_PASSWORD,OWNER_ADDRESS,OWNER_CONTACT,OWNER_GENDER,DOB)values('$name','$email','$pass',' $address','$contactno','$gender','$dob')";
    $res = $conn->query($sql);
    header('location:../owner.php?success=success');
} else {
    header('location:../owner.php?error=error');
}
 