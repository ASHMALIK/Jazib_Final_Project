<?php
session_start();
if (isset($_SESSION[ 'ownerloginstatus'])) {
    unset($_SESSION[ 'ownerloginstatus']);
    session_destroy();
    header('location:../owner.php');
} else {
    header('location:../owner.php');
}

 ?>