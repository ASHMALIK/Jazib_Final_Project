-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.33-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for online property rental and verification system
CREATE DATABASE IF NOT EXISTS `online property rental and verification system` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `online property rental and verification system`;


-- Dumping structure for table online property rental and verification system.tbl_admin
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(250) NOT NULL,
  `PASSWORD` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table online property rental and verification system.tbl_admin: ~0 rows (approximately)
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
REPLACE INTO `tbl_admin` (`ID`, `USERNAME`, `PASSWORD`) VALUES
	(1, 'admin', '786123');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;


-- Dumping structure for table online property rental and verification system.tbl_agents
CREATE TABLE IF NOT EXISTS `tbl_agents` (
  `AGENT_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `AGENT_NAME` varchar(250) NOT NULL,
  `AGENT_EMAIL` varchar(250) NOT NULL,
  `AGENT_PASSWORD` varchar(250) NOT NULL,
  `AGENT_ADDRESS` varchar(250) DEFAULT NULL,
  `AGENT_CONTACT` varchar(250) DEFAULT NULL,
  `AGENT_GENDER` varchar(250) NOT NULL,
  `DOB` date NOT NULL,
  `AGENT_PRICE` varchar(250) DEFAULT NULL,
  `STATUS` int(11) unsigned NOT NULL DEFAULT '0',
  `REGISTERATION_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`AGENT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table online property rental and verification system.tbl_agents: ~1 rows (approximately)
/*!40000 ALTER TABLE `tbl_agents` DISABLE KEYS */;
REPLACE INTO `tbl_agents` (`AGENT_ID`, `AGENT_NAME`, `AGENT_EMAIL`, `AGENT_PASSWORD`, `AGENT_ADDRESS`, `AGENT_CONTACT`, `AGENT_GENDER`, `DOB`, `AGENT_PRICE`, `STATUS`, `REGISTERATION_TIME`) VALUES
	(2, 'HSY', 'Hsy@gmail.com', 'hs2345', 'pskt', '0333548', 'Male', '2019-03-08', ' 50000', 1, '2019-03-19 17:27:32');
/*!40000 ALTER TABLE `tbl_agents` ENABLE KEYS */;


-- Dumping structure for table online property rental and verification system.tbl_customers
CREATE TABLE IF NOT EXISTS `tbl_customers` (
  `CUSTOMER_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `CUSTOMER_NAME` varchar(250) NOT NULL,
  `CUSTOMER_EMAIL` varchar(250) NOT NULL,
  `CUSTOMER_PASSWORD` varchar(250) NOT NULL,
  `CUSTOMER_ADDRESS` varchar(250) DEFAULT NULL,
  `CUSTOMER_CONTACT` varchar(250) DEFAULT NULL,
  `CUSTOMER_GENDER` varchar(250) NOT NULL,
  `DOB` date NOT NULL,
  `STATUS` int(10) unsigned NOT NULL DEFAULT '0',
  `REGISTERATION_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CUSTOMER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table online property rental and verification system.tbl_customers: ~2 rows (approximately)
/*!40000 ALTER TABLE `tbl_customers` DISABLE KEYS */;
REPLACE INTO `tbl_customers` (`CUSTOMER_ID`, `CUSTOMER_NAME`, `CUSTOMER_EMAIL`, `CUSTOMER_PASSWORD`, `CUSTOMER_ADDRESS`, `CUSTOMER_CONTACT`, `CUSTOMER_GENDER`, `DOB`, `STATUS`, `REGISTERATION_TIME`) VALUES
	(5, 'Arslan', 'Ash@gmail.com', 'as1234', 'PSKT01', '033354856', 'Male', '2019-03-30', 1, '2019-03-19 17:26:29');
/*!40000 ALTER TABLE `tbl_customers` ENABLE KEYS */;


-- Dumping structure for table online property rental and verification system.tbl_owners
CREATE TABLE IF NOT EXISTS `tbl_owners` (
  `OWNER_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `OWNER_NAME` varchar(250) NOT NULL,
  `OWNER_EMAIL` varchar(250) NOT NULL,
  `OWNER_PASSWORD` varchar(250) NOT NULL,
  `OWNER_ADDRESS` varchar(250) NOT NULL,
  `OWNER_CONTACT` varchar(250) NOT NULL,
  `OWNER_GENDER` varchar(250) NOT NULL,
  `DOB` date NOT NULL,
  `STATUS` int(11) unsigned NOT NULL DEFAULT '0',
  `REGISTERATION_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`OWNER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table online property rental and verification system.tbl_owners: ~1 rows (approximately)
/*!40000 ALTER TABLE `tbl_owners` DISABLE KEYS */;
REPLACE INTO `tbl_owners` (`OWNER_ID`, `OWNER_NAME`, `OWNER_EMAIL`, `OWNER_PASSWORD`, `OWNER_ADDRESS`, `OWNER_CONTACT`, `OWNER_GENDER`, `DOB`, `STATUS`, `REGISTERATION_TIME`) VALUES
	(1, 'Malik', 'ms@gmail.com', 'ms1234', ' pskt', '03354875265', 'Male', '2019-03-14', 1, '2019-03-19 17:31:19');
/*!40000 ALTER TABLE `tbl_owners` ENABLE KEYS */;


-- Dumping structure for table online property rental and verification system.tbl_property
CREATE TABLE IF NOT EXISTS `tbl_property` (
  `PROPERTY_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `OWNER_ID` int(11) unsigned NOT NULL,
  `AGENT_ID` int(11) unsigned DEFAULT NULL,
  `CUSTOMER_ID` int(11) unsigned DEFAULT NULL,
  `PROPERTY_TYPE` varchar(250) NOT NULL,
  `CITY` varchar(250) NOT NULL,
  `STREET_NO` int(11) unsigned NOT NULL,
  `HOUSE_NO` int(11) unsigned NOT NULL,
  `HOUSE_NAME` varchar(250) NOT NULL,
  `SIZE` varchar(250) NOT NULL,
  `TOTAL_ROOMS` varchar(250) NOT NULL,
  `IMAGE` varchar(250) NOT NULL,
  `RENT` varchar(250) NOT NULL,
  `RENT_AGREEMENT` text NOT NULL,
  `PROPERTY_STATUS` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PROPERTY_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table online property rental and verification system.tbl_property: ~6 rows (approximately)
/*!40000 ALTER TABLE `tbl_property` DISABLE KEYS */;
REPLACE INTO `tbl_property` (`PROPERTY_ID`, `OWNER_ID`, `AGENT_ID`, `CUSTOMER_ID`, `PROPERTY_TYPE`, `CITY`, `STREET_NO`, `HOUSE_NO`, `HOUSE_NAME`, `SIZE`, `TOTAL_ROOMS`, `IMAGE`, `RENT`, `RENT_AGREEMENT`, `PROPERTY_STATUS`) VALUES
	(1, 1, 2, 5, 'Land', ' SKT', 32, 5, 'MALIK PALACE', '5 Marla', '5', 'download (1).jpg', '15000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '1'),
	(2, 1, 2, 5, 'HOUSE', ' LAHORE', 45, 3, 'AGHA PALACE', '10 Marla', '10', 'images (1).jpg', '30,000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '1'),
	(3, 1, 2, 5, 'HOUSE', ' Karachi', 50, 10, 'BARKAT PALACE', '10 Marla', '10', '89318860137bae6acf5a260778b645cb.jpg', '40,000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '1'),
	(4, 1, 2, NULL, 'HOUSE', ' LAHORE', 10, 1, 'JUTT HOUSE', '15 Marla', '12', 'images 55.jpg', '40,000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '0'),
	(5, 1, 2, NULL, 'BUILDING', ' SIALKOT', 20, 2, 'REAL ESTATE BROTHERS', '20 Marla', '25', 'images 45.jpg', '60,000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '0'),
	(6, 1, 2, NULL, 'HOUSE', ' SIALKOT', 50, 3, 'MALIK HOUSE', '20 Marla', '15', 'images44.jpg', '50,000', ' fddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhjfddddddserfasytdhj', '0');
/*!40000 ALTER TABLE `tbl_property` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
