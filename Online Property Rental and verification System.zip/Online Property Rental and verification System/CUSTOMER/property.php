<?php
include_once('../db/config.php');
session_start();
if (isset($_SESSION['customerloginstatus']) and $_SESSION['customerloginstatus'] == true) {

    ?>
<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" media="screen" href="../css/main.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>


    <div class="navbar navbar-inverse">
        <div class="container-fluid">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="dashboard.php"><span class="glyphicon glyphicon-home">Home</a>
        <a href="property.php"><span class="glyphicon glyphicon-home">Properties</a>
        <a href="purchased_property.php"><span class="glyphicon glyphicon-home">Purchased_Property</a>


    </div>



    <div id="main">
        <?php
        if (isset($_GET['success'])) {

            ?>
        <div class="alert alert-success alert-dismissible " role="alert">
            <strong>Property Purchased For Rent Successfully!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    } else if (isset($_GET['error'])) {
        ?>
        <div class="alert alert-warning alert-dismissible " role="alert">
            <strong>Propert Already Purchased For Rent!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    }
    ?>

        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
        <div class="row">

            <h1 class="container text-center"><span class="glyphicon glyphicon-home">FeaturedProperties</h1>

        </div>
    </div>
    <br>
    <br>
    <br>
    <?php 
    $sql = "select * from tbl_property";
    $res = $conn->query($sql);
    while ($rec = $res->fetch_array()) {
        extract($rec);
        ?>

    <div class="container text-center">
        <div class="row">
            <div class="col-sm-4">
                <div class="panel panel-primary">

                    <?php
                    if ($PROPERTY_STATUS == 0) {
                        ?>
                    <div class="panel-heading">AVAILABLE FOR RENT</div>
                    <?php

                } elseif ($PROPERTY_STATUS == 1) {
                    ?>
                    <div class="panel-heading">NOT AVAILABLE FOR RENT</div>
                    <?php

                }
                ?>


                    <div class="panel-body"><img src="../Property_images/<?= $IMAGE ?>" class="img-responsive" style="width:328px" alt="Image"></div>
                    <div class="panel-footer"><a href="buyproperty.php?id=<?= $PROPERTY_ID ?>&owner_id=<?= $OWNER_ID ?>&agent_id=<?= $AGENT_ID ?>">Buy a Luxory Property for Rent <span class="glyphicon glyphicon-arrow-right"></a></div>
                </div>
            </div>
            <?php 
        }
        ?>



        </div>
    </div><br><br>
    </div>




    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
    </script>

    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>

    <script>
        $('#example23').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'csv', 'excel', 'pdf', 'print'
            ]
        });
    </script>



</body>

</html>

<?php

} else {
    header('location:logout.php');
}
?> 