<?php
session_start();
if (isset($_SESSION[ 'customerloginstatus'])) {
    unset($_SESSION[ 'customerloginstatus']);
    session_destroy();
    header('location:../customer.php');
} else {
    header('location:../customer.php');
}

 ?>