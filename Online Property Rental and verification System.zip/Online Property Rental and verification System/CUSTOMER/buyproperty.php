<?php
include_once('../db/config.php');
session_start();
if (isset($_SESSION['customerloginstatus']) and $_SESSION['customerloginstatus'] == true) {

    ?>

<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" media="screen" href="../css/main.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>


    <div class="navbar navbar-inverse">
        <div class="container-fluid">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="dashboard.php"><span class="glyphicon glyphicon-home">Home</a>
        <a href="property.php"><span class="glyphicon glyphicon-home">Properties</a>
        <a href="purchased_property.php"><span class="glyphicon glyphicon-home">Purchased_Property</a>


    </div>



    <div id="main">

        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

        <div class="container-fluid">
            <div class="row content">

                <br>
                <?php 
                $owner_id = $_GET['owner_id'];
                $sql = "select * from tbl_owners where OWNER_ID='$owner_id' ";
                $res = $conn->query($sql);
                $rec = $res->fetch_array();
                extract($rec);
                ?>

                <?php 
                $agent_id = $_GET['agent_id'];
                $sql2 = "select * from tbl_agents where AGENT_ID='$agent_id' ";
                $res2 = $conn->query($sql2);
                $rec2 = $res2->fetch_array();
                extract($rec2);
                ?>

                <?php 
                $id = $_GET['id'];
                $sql1 = "select * from tbl_property where PROPERTY_ID='$id' ";
                $res1 = $conn->query($sql1);
                $rec1 = $res1->fetch_array();
                extract($rec1);
                ?>

                <div class="col-sm-12">
                    <div class="well">
                        <h4>IMAGE</h4>
                        <p><img src="../Property_images/<?= $IMAGE ?>"></p>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="well">
                                <p>PROPERTY_STATUS</p>
                                <?php
                                if ($PROPERTY_STATUS == 0) {
                                    ?>
                                <p>AVAILABLE FOR RENT</p>
                                <?php

                            } elseif ($PROPERTY_STATUS == 1) {
                                ?>
                                <p>NOT AVAILABLE FOR RENT</p>
                                <?php

                            }
                            ?>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="well">
                                <p>Owner</p>
                                <p><?= $OWNER_NAME ?></p>

                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="well">
                                <p>AGENT</p>
                                <p><?= $AGENT_NAME ?></p>

                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="well">
                                <h4>CITY</h4>
                                <p><?= $CITY ?></p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="well">
                                <h4>STREET_NO</h4>
                                <p><?= $STREET_NO ?></p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="well">
                                <h4>HOUSE_NO</h4>
                                <p><?= $HOUSE_NO ?></p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="well">
                                <h4>HOUSE_NAME</h4>
                                <p><?= $HOUSE_NAME ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="well">
                                <p>SIZE</p>
                                <p><?= $SIZE ?></p>

                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="well">
                                <p>TOTAL_ROOMS</p>
                                <p><?= $TOTAL_ROOMS ?></p>

                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="well">
                                <p>RENT</p>
                                <p><?= $RENT ?></p>

                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="well">
                                <h4>RENT_AGREEMENT</h4>
                                <p><?= $RENT_AGREEMENT ?></p>
                            </div>
                        </div>
                        <div class="col-sm-12">

                            <a href="MODULE/saleproperty.php?id=<?= $id ?>"><button class="btn btn-success">BUY</button></a>

                        </div>


                    </div>
                </div>
            </div>


        </div>




        <script>
            function openNav() {
                document.getElementById("mySidenav").style.width = "250px";
                document.getElementById("main").style.marginLeft = "250px";
            }

            function closeNav() {
                document.getElementById("mySidenav").style.width = "0";
                document.getElementById("main").style.marginLeft = "0";
            }
        </script>

        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

        <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>

        <script>
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'csv', 'excel', 'pdf', 'print'
                ]
            });
        </script>



</body>

</html>







<?php

} else {
    header('location:logout.php');
}
?> 