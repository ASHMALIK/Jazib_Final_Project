<?php
 session_start();
include_once("../../db/config.php");

   $customer_id= $_SESSION['ID'];
   $id=$_GET['id'];

$sql1 = "select * from tbl_property where PROPERTY_ID='$id'";
$res1 = $conn->query($sql1);
$rec1=$res1->fetch_array();
extract($rec1);

if($PROPERTY_STATUS=='0'){


  $sql = "update tbl_property set CUSTOMER_ID='$customer_id',PROPERTY_STATUS='1' where PROPERTY_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../property.php?success=success');
}else{
   header('location:../property.php?error=error');
}
 ?>