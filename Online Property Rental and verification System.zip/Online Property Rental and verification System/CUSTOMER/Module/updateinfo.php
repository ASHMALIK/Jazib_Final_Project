<?php
session_start();
include_once("../../db/config.php");

if (isset($_POST['submit'])) {
   $id=$_SESSION['ID'];
    $address = $_POST[ 'address'];
    $contact = $_POST[ 'contact'];
    
  $sql = "update tbl_customers set CUSTOMER_ADDRESS='$address',CUSTOMER_CONTACT='$contact' where CUSTOMER_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../dashboard.php?success=success');
} else {
    header( 'location:../dashboard.php?error=error');
}
 ?>