<?php
 include_once("../db/config.php");

$email = $_REQUEST[ 'email'];
$pass = $_REQUEST[ 'pwd'];

 $sql = "select * from tbl_customers where CUSTOMER_EMAIL='$email' and CUSTOMER_PASSWORD='$pass' and STATUS='1' ";

$res = $conn->query($sql);
$rec = $res->fetch_array();
if (mysqli_num_rows($res) == 1) {
    session_start();
    $_SESSION['customerloginstatus'] = true;
 $_SESSION['ID'] = $rec['CUSTOMER_ID'];

    header('location:dashboard.php?login=succesfully&ID=' . $_SESSION['ID']);
} else {
    header('location:../customer.php?error=error');
}

 ?>