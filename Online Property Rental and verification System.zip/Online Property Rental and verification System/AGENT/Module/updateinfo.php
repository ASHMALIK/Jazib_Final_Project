<?php
session_start();
include_once("../../db/config.php");

if (isset($_POST['submit'])) {
   $id=$_SESSION['ID'];
    $address = $_POST[ 'address'];
    $contact = $_POST[ 'contact'];
   $price= $_POST[ 'price'];
    
  $sql = "update tbl_agents set AGENT_ADDRESS='$address',AGENT_CONTACT='$contact',AGENT_PRICE=' $price' where AGENT_ID='$id' ";

    $res = $conn->query($sql);
    header('location:../dashboard.php?success=success');
} else {
    header( 'location:../dashboard.php?error=error');
}
 ?>