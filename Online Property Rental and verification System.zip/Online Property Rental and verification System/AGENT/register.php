<?php
include_once("../db/config.php");

if(isset($_POST['submit'])){
 $name=$_POST['name'];
 $email=$_POST['email'];
 $pass=$_POST['pwd'];
 $gender=$_POST['gender'];
 $dob=$_POST['dob'];

$sql= "insert into tbl_agents (AGENT_NAME,AGENT_EMAIL,AGENT_PASSWORD,AGENT_GENDER,DOB)values('$name','$email','$pass','$gender','$dob')";
$res=$conn->query($sql);
header('location:../agent.php?success=success');
} else {
    header( 'location:../agent.php?error=error');
}


?>