<?php
session_start();
if (isset($_SESSION[ 'agentloginstatus'])) {
    unset($_SESSION[ 'agentloginstatus']);
    session_destroy();
    header('location:../agent.php');
} else {
    header('location:../agent.php');
}

 ?>