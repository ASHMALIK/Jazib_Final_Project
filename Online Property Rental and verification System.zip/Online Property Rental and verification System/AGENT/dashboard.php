<?php
include_once('../db/config.php');
session_start();
if (isset($_SESSION['agentloginstatus']) and $_SESSION['agentloginstatus'] == true) {

    ?>
<!Doctype <!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Property Rental and verification System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" media="screen" href="../css/main.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>


    <div class="navbar navbar-inverse">
        <div class="container-fluid">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="dashboard.php"><span class="glyphicon glyphicon-home">Home</a>

    </div>



    <div id="main">
        <?php
        if (isset($_GET['success'])) {

            ?>
        <div class="alert alert-success alert-dismissible " role="alert">
            <strong>Info updated successfully!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    } else if (isset($_GET['error'])) {
        ?>
        <div class="alert alert-warning alert-dismissible " role="alert">
            <strong>Something Wrong Check it!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php 
    }
    ?>


        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
        <div class="container">
            <h1 class="text-center">Upload Your information</h1>
            <form method="post" action="Module/updateinfo.php">
                <div class="form-group">
                    <label>Address :</label>
                    <textarea class="form-control" id="text" placeholder="Enter Your Address........" name="address" required=""></textarea>
                </div>
                <div class="form-group">
                    <label>Contact No :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter Your contact No." name="contact" required="">
                </div>
                <div class="form-group">
                    <label>Price :</label>
                    <input type="text" class="form-control" id="text" placeholder="Enter the price" name="price" required="">
                </div>

                <input type="submit" name="submit" Value="upload" class="btn btn-info">
                <form>
        </div>
        <br>


        <div class="container-fluid">

            <div class="row">


                <div class="col-sm-12">
                    <div class="white-box">
                        <h3 class="box-title m-b-0">Data Export</h3>
                        <p class="text-muted m-b-30">Export data to CSV, Excel, PDF & Print</p>
                        <div class="table-responsive">
                            <table id="example23" class="display nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>NAME</th>
                                        <th>EMAIL</th>
                                        <th>ADDRESS</th>
                                        <th>CONTACT NO.</th>
                                        <th>GENDER</th>
                                        <th>PRICE</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $id = $_SESSION['ID'];
                                    $sql = "select * from tbl_agents where AGENT_ID='$id' ";
                                    $res = $conn->query($sql);
                                    $rec = $res->fetch_array();
                                    extract($rec);
                                    ?>




                                    <tr>
                                        <td><?= $AGENT_ID ?></td>
                                        <td><?= $AGENT_NAME ?></td>
                                        <td><?= $AGENT_EMAIL ?></td>
                                        <td><?= $AGENT_ADDRESS ?></td>
                                        <td><?= $AGENT_CONTACT ?></td>
                                        <td><?= $AGENT_GENDER ?></td>
                                        <td><?= $AGENT_PRICE ?></td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>

        </div>
    </div>





    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
    </script>

    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>

    <script>
        $('#example23').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'csv', 'excel', 'pdf', 'print'
            ]
        });
    </script>



</body>

</html>

<?php

} else {
    header('location:logout.php');
}
?> 