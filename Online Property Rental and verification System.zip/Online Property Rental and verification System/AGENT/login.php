<?php
 include_once("../db/config.php");

$email = $_REQUEST[ 'email'];
$pass = $_REQUEST[ 'pwd'];

 $sql = "select * from tbl_agents where AGENT_EMAIL='$email' and AGENT_PASSWORD='$pass' and STATUS='1' ";

$res = $conn->query($sql);
$rec = $res->fetch_array();
if (mysqli_num_rows($res) == 1) {
    session_start();
    $_SESSION[ 'agentloginstatus'] = true;
  $_SESSION['ID'] = $rec[ 'AGENT_ID'];

    header('location:dashboard.php?login=succesfully&ID=' . $_SESSION['ID']);
} else {
    header('location:../agent.php?error=error');
}

 ?>